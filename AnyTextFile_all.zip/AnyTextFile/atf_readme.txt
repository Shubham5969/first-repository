http://sourceforge.net/projects/anytextfile
programmer: Aleksandar Josifoski
email: josifoski@gmail.com
programming platform: lazarus
licence: gpl

Idea of program is reading text file per sentence, 
with clicking or with auto time renewal.

shortcuts: 
Left key: Previous sentence
Right key: Next sentence

.txt file should be in format starting with
$$$ for chapters and in every line sentence.
File must start with $$$
Sentence does not have to end with a dot may be
a logical block but in the text file must be in a single row. 

There is txt2dot program which is auxiliary tool
for creating new text files based on existing ones
which are divided by sentence (separated with dot)

If You are interested in reading spiritual books
Create parallel Bible translations program
http://sourceforge.net/projects/printcrippledbi/
can be very usefull for creating .txt files
for reading with this tiny program.


